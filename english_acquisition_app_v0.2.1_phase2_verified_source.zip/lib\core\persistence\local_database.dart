import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqlite3/sqlite3.dart';

final class LocalDatabase {
  LocalDatabase._(this._database);

  final Database _database;

  static Future<LocalDatabase> open() async {
    final directory = await getApplicationSupportDirectory();
    final databaseDirectory = Directory(
      '${directory.path}${Platform.pathSeparator}data',
    );
    await databaseDirectory.create(recursive: true);
    final database = sqlite3.open(
      '${databaseDirectory.path}${Platform.pathSeparator}english_acquisition.sqlite3',
    );
    final localDatabase = LocalDatabase._(database);
    localDatabase._migrate();
    return localDatabase;
  }

  static LocalDatabase inMemory() {
    final localDatabase = LocalDatabase._(sqlite3.openInMemory());
    localDatabase._migrate();
    return localDatabase;
  }

  Database get raw => _database;

  void _migrate() {
    _database.execute('PRAGMA foreign_keys = ON;');
    _database.execute('''
      CREATE TABLE IF NOT EXISTS learner_profiles (
        learner_id TEXT NOT NULL PRIMARY KEY,
        display_name TEXT NOT NULL,
        native_language TEXT NOT NULL,
        english_level TEXT NOT NULL,
        occupational_role TEXT NOT NULL,
        industry TEXT NOT NULL,
        procurement_experience_years INTEGER NOT NULL,
        communication_tasks TEXT NOT NULL,
        preferred_session_minutes INTEGER NOT NULL,
        accessibility_notes TEXT NOT NULL,
        updated_at TEXT NOT NULL
      ) STRICT;
    ''');
    _database.execute('''
      CREATE TABLE IF NOT EXISTS learner_goals (
        id TEXT NOT NULL PRIMARY KEY,
        learner_id TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        occupational_context TEXT NOT NULL,
        priority INTEGER NOT NULL,
        status TEXT NOT NULL,
        target_date TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      ) STRICT;
    ''');
    _database.execute('''
      CREATE INDEX IF NOT EXISTS idx_goals_learner_priority
      ON learner_goals (learner_id, status, priority, updated_at);
    ''');
  }

  void close() => _database.close();
}
