import 'package:english_acquisition_app/core/security/secure_session_store.dart';
import 'package:english_acquisition_app/features/authentication/application/controllers/authentication_controller.dart';
import 'package:english_acquisition_app/features/authentication/data/repositories/local_two_user_authentication_repository.dart';
import 'package:english_acquisition_app/features/authentication/domain/value_objects/authentication_status.dart';
import 'package:flutter_test/flutter_test.dart';

final class MemorySessionStore implements SecureSessionStore {
  String? value;
  @override
  Future<void> clear() async => value = null;
  @override
  Future<String?> readUserId() async => value;
  @override
  Future<void> writeUserId(String userId) async => value = userId;
}

void main() {
  test('controller rejects invalid credentials', () async {
    final controller = AuthenticationController(
      LocalTwoUserAuthenticationRepository(MemorySessionStore()),
    );
    await controller.initialize();
    await controller.signIn(userName: 'wrong', password: 'wrong');
    expect(controller.status, AuthenticationStatus.unauthenticated);
    expect(controller.errorMessage, isNotNull);
  });
}
