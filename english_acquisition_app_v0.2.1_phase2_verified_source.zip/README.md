# English Acquisition App - Phase 2 Profile and Goals

Version `0.2.0+4`.

This cumulative package contains the verified Windows Phase 1 foundation plus Phase 2:

- learner profile
- learner goals
- Home summary
- learner-scoped SQLite persistence
- user isolation tests

## Setup and verify

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\bootstrap_verify_and_run_windows.ps1
```

## Development run

```powershell
.\scripts\run_windows.ps1
```

## Release run

```powershell
.\scripts\run_windows_release.ps1
```

The scripts preserve the Flutter 3.47 Windows debug workaround by disabling Impeller for development. Release execution remains the runtime acceptance target.

See `PHASE2_PLAN.md`, `PHASE1_STATUS.md`, and `KNOWN_ISSUES.md`.
