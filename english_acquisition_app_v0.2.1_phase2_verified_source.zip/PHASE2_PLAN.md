# Phase 2 Plan and Acceptance

## Implemented in this package

- learner-scoped SQLite database
- learner profile create, load, edit, and validation
- goals create, load, edit, prioritize, status, and delete
- Home summary for profile and active goals
- user isolation by `learner_id`
- four automated Phase 2 persistence/controller checks when combined with Phase 1 tests
- Windows debug workaround and release validation scripts retained

## Acceptance gates

1. `flutter pub get`
2. `dart format --output=none --set-exit-if-changed lib test tool`
3. `flutter analyze`
4. `flutter test`
5. `flutter build windows --release`
6. release runtime remains stable
7. User A creates profile and goal
8. User A signs out
9. User B signs in and cannot see User A profile or goals
10. User A signs in again and sees persisted data

## Deferred to backend slice

- production authentication
- server acceptance and synchronization
- remote conflict resolution
- encrypted relational database

The local database is a real, structured offline store. Consequential remote finalization will be introduced with the .NET backend rather than simulated in the client.

## Repair 0.2.1

- Resolved all 12 analyzer findings reported during the first Windows verification.
- Added required braces to router and goal menu control flow.
- Removed the unused goal entity import.
- Replaced multiple-underscore callback names with meaningful parameter names.
