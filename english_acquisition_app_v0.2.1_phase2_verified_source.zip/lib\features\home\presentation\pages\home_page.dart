import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/phase2_providers.dart';
import '../../../authentication/authentication.dart';

final class HomePage extends ConsumerWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authenticationControllerProvider);
    final profileState = ref.watch(learnerProfileControllerProvider);
    final goalsState = ref.watch(goalsControllerProvider);
    return ListenableBuilder(
      listenable: auth,
      builder: (context, child) => Scaffold(
        appBar: AppBar(
          title: const Text('Today'),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: auth.signOut,
              tooltip: 'Sign out',
            ),
          ],
        ),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1000),
            child: ListView(
              padding: const EdgeInsets.all(32),
              children: [
                Text(
                  'Welcome, ${auth.user?.displayName ?? 'Learner'}',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 20),
                Wrap(
                  spacing: 16,
                  runSpacing: 16,
                  children: [
                    _SummaryCard(
                      icon: Icons.person,
                      title: 'Learner profile',
                      body: profileState.when(
                        loading: () => 'Loading...',
                        error: (e, s) => 'Needs attention',
                        data: (c) => c.profile == null
                            ? 'Not created'
                            : c.profile!.isComplete
                            ? 'Complete'
                            : 'Incomplete',
                      ),
                      onTap: () => context.go('/profile'),
                    ),
                    _SummaryCard(
                      icon: Icons.flag,
                      title: 'Active goals',
                      body: goalsState.when(
                        loading: () => 'Loading...',
                        error: (e, s) => 'Needs attention',
                        data: (c) =>
                            '${c.goals.where((g) => g.status.name == 'active').length} active',
                      ),
                      onTap: () => context.go('/goals'),
                    ),
                    const _SummaryCard(
                      icon: Icons.school,
                      title: 'Next learning action',
                      body:
                          'Phase 3 will connect the learning plan and practice loop.',
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Phase 2 stores profile and goal data in a learner-scoped local SQLite database. Each authenticated user sees only records matching the current learner ID.',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

final class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.body,
    required this.icon,
    required this.title,
    this.onTap,
  });
  final String body;
  final IconData icon;
  final String title;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => SizedBox(
    width: 300,
    child: Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 32),
              const SizedBox(height: 12),
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(body),
            ],
          ),
        ),
      ),
    ),
  );
}
