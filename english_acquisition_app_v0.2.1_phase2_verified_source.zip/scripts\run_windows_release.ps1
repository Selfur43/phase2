$ErrorActionPreference = 'Stop'
if (-not (Test-Path '.\pubspec.yaml')) {
    throw "Run this script from the project root where pubspec.yaml exists. Current folder: $(Get-Location)"
}
flutter build windows --release
if ($LASTEXITCODE -ne 0) {
    throw "Windows release build failed with exit code $LASTEXITCODE."
}
$releaseExe = '.\build\windows\x64\runner\Release\english_acquisition_app.exe'
if (-not (Test-Path $releaseExe)) {
    throw "Release executable was not found: $releaseExe"
}
Start-Process -FilePath $releaseExe
