import 'dart:io';

void main() {
  const required = <String>[
    'pubspec.yaml',
    'lib/main.dart',
    'lib/app/application.dart',
    'lib/app/routing/app_router.dart',
    'lib/core/persistence/local_database.dart',
    'lib/features/authentication/authentication.dart',
    'lib/features/home/presentation/pages/home_page.dart',
    'lib/features/learner_profile/presentation/pages/learner_profile_page.dart',
    'lib/features/goals/presentation/pages/goals_page.dart',
    'test/authentication_repository_test.dart',
    'test/phase2_persistence_test.dart',
  ];
  final missing = required.where((p) => !File(p).existsSync()).toList();
  if (missing.isNotEmpty) {
    stderr.writeln('Missing required files: ${missing.join(', ')}');
    exitCode = 1;
    return;
  }
  stdout.writeln('Phase 2 source structure is complete.');
}
