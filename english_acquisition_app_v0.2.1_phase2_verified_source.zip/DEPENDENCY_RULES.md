# Phase 1 Dependency Rules

1. `app` owns composition and routing.
2. `core` never imports app or features.
3. Domain code is pure Dart.
4. Application depends on domain abstractions, never data implementations.
5. Data adapters implement domain repositories.
6. Feature pages are exported through feature public files.
7. Provider credentials and real passwords must never be packaged in the client.
8. The local authentication adapter is development-only and must be replaced by .NET authentication before release.
