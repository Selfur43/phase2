# Known Issues

## Flutter 3.47.9 Windows debug renderer

Observed behavior:

- default debug execution starts and then exits
- no Dart exception is emitted
- Windows Event ID 1000 names `flutter_windows.dll`
- exception code is `0xc0000005`
- release build is stable
- debug execution with `--no-enable-impeller` is usable

Mitigation:

```powershell
flutter run -d windows --no-enable-impeller
```

Do not treat Android SDK or Chrome doctor warnings as Windows build failures. Re-test the default renderer after upgrading Flutter stable in a controlled maintenance branch.
