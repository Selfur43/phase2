import '../../../../core/security/secure_session_store.dart';
import '../../domain/entities/authenticated_user.dart';
import '../../domain/failures/authentication_failure.dart';
import '../../domain/repositories/authentication_repository.dart';

/// Windows-first Phase 1 development adapter. Replace with .NET authentication before release.
final class LocalTwoUserAuthenticationRepository
    implements AuthenticationRepository {
  const LocalTwoUserAuthenticationRepository(this._sessionStore);

  final SecureSessionStore _sessionStore;

  static const _users = <String, AuthenticatedUser>{
    'furkan': AuthenticatedUser(displayName: 'Furkan', id: 'learner-1'),
    'learner2': AuthenticatedUser(displayName: 'Learner 2', id: 'learner-2'),
  };

  @override
  Future<AuthenticatedUser?> restore() async {
    final userId = await _sessionStore.readUserId();
    for (final user in _users.values) {
      if (user.id == userId) return user;
    }
    return null;
  }

  @override
  Future<AuthenticatedUser> signIn({
    required String password,
    required String userName,
  }) async {
    final user = _users[userName.trim().toLowerCase()];
    if (user == null || password != 'change-me-now') {
      throw const AuthenticationFailure('Invalid user name or password.');
    }
    await _sessionStore.writeUserId(user.id);
    return user;
  }

  @override
  Future<void> signOut() => _sessionStore.clear();
}
