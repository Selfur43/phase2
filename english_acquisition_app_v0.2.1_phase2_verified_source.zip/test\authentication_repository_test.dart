import 'package:english_acquisition_app/core/security/secure_session_store.dart';
import 'package:english_acquisition_app/features/authentication/data/repositories/local_two_user_authentication_repository.dart';
import 'package:flutter_test/flutter_test.dart';

final class MemorySessionStore implements SecureSessionStore {
  String? value;
  @override
  Future<void> clear() async => value = null;
  @override
  Future<String?> readUserId() async => value;
  @override
  Future<void> writeUserId(String userId) async => value = userId;
}

void main() {
  test('sign-in, restore, and sign-out are consistent', () async {
    final store = MemorySessionStore();
    final repository = LocalTwoUserAuthenticationRepository(store);
    final user = await repository.signIn(
      password: 'change-me-now',
      userName: 'furkan',
    );
    expect(user.id, 'learner-1');
    expect((await repository.restore())?.id, 'learner-1');
    await repository.signOut();
    expect(await repository.restore(), isNull);
  });
}
