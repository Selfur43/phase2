$ErrorActionPreference = 'Stop'

function Invoke-NativeCommand {
    param(
        [Parameter(Mandatory = $true)][string]$Executable,
        [Parameter(Mandatory = $true)][string[]]$ArgumentList
    )

    $previousErrorActionPreference = $ErrorActionPreference
    try {
        $script:ErrorActionPreference = 'Continue'
        & $Executable @ArgumentList
        $nativeExitCode = $LASTEXITCODE
    }
    finally {
        $script:ErrorActionPreference = $previousErrorActionPreference
    }

    if ($nativeExitCode -ne 0) {
        throw "Command failed with exit code ${nativeExitCode}: $Executable $($ArgumentList -join ' ')"
    }
}

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw 'Flutter is not installed or is not available in PATH.'
}
if (-not (Test-Path '.\pubspec.yaml')) {
    throw "Run this script from the project root where pubspec.yaml exists. Current folder: $(Get-Location)"
}

Write-Host 'Checking Flutter and Windows toolchain...' -ForegroundColor Cyan
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('doctor', '-v')

Write-Host 'Enabling Windows desktop support...' -ForegroundColor Cyan
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('config', '--enable-windows-desktop')

Write-Host 'Generating or refreshing the Windows host project...' -ForegroundColor Cyan
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('create', '--platforms=windows', '.')
Remove-Item '.\windows\.gitkeep' -ErrorAction SilentlyContinue
Remove-Item '.\test\widget_test.dart' -ErrorAction SilentlyContinue

Write-Host 'Resolving packages...' -ForegroundColor Cyan
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('pub', 'get')

Write-Host 'Formatting and validating...' -ForegroundColor Cyan
Invoke-NativeCommand -Executable 'dart' -ArgumentList @('format', 'lib', 'test', 'tool')
Invoke-NativeCommand -Executable 'dart' -ArgumentList @('run', 'tool/validate_phase1.dart')
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('analyze')
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('test')

Write-Host 'Building Windows debug and release applications...' -ForegroundColor Cyan
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('build', 'windows', '--debug')
Invoke-NativeCommand -Executable 'flutter' -ArgumentList @('build', 'windows', '--release')

Write-Host 'Verification completed successfully.' -ForegroundColor Green
Write-Host 'Starting the stable Windows release build...' -ForegroundColor Green
$releaseExe = '.\build\windows\x64\runner\Release\english_acquisition_app.exe'
if (-not (Test-Path $releaseExe)) {
    throw "Release executable was not found: $releaseExe"
}
Start-Process -FilePath $releaseExe
